"""
A&I ARMOUR - Real AI Integration Guide
How to connect actual Grok, Claude, and other AI APIs
"""

# ============================================================================
# STEP 1: Install AI SDK Libraries
# ============================================================================

# These are already in requirements.txt, but here's what they do:
# - anthropic: Claude API client
# - openai: OpenAI API client (also works for Grok via compatible endpoint)

# ============================================================================
# STEP 2: Configure API Clients
# ============================================================================

import os
from anthropic import Anthropic
from openai import OpenAI

# Grok API (via OpenAI-compatible endpoint)
grok_client = OpenAI(
    api_key=os.getenv("GROK_API_KEY"),
    base_url="https://api.x.ai/v1"  # Grok's API endpoint
)

# Claude API
claude_client = Anthropic(
    api_key=os.getenv("CLAUDE_API_KEY")
)

# ============================================================================
# STEP 3: Update AIAgent Base Class in backend.py
# ============================================================================

# Replace the simulated API calls with real ones:

async def execute_with_grok(self, task: str, context: Dict) -> Dict:
    """Execute task with Grok API (REAL VERSION)"""
    
    try:
        # Construct prompt
        prompt = f"""You are a business automation AI for A&I Armour (AI security company).
        
Task: {task}
Context: {json.dumps(context, indent=2)}

Execute this task efficiently. Return results in JSON format with:
- action_taken: what you did
- result: the outcome
- data: any relevant data
- confidence: your confidence level (0-1)

Be concise and accurate. This is a real business operation."""

        # Call Grok API
        response = grok_client.chat.completions.create(
            model="grok-beta",  # Use latest Grok model
            messages=[
                {"role": "system", "content": "You are a business automation AI."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,  # Lower temp for more consistent business operations
            max_tokens=1000
        )
        
        # Parse response
        result_text = response.choices[0].message.content
        
        # Try to parse as JSON, fallback to text
        try:
            result_data = json.loads(result_text)
        except:
            result_data = {
                "action_taken": task,
                "result": result_text,
                "confidence": 0.85
            }
        
        return {
            "agent": self.agent_type.value,
            "task": task,
            "grok_response": result_data,
            "raw_response": result_text
        }
        
    except Exception as e:
        return {
            "agent": self.agent_type.value,
            "task": task,
            "error": str(e),
            "success": False
        }


async def verify_with_claude(self, result: Dict, original_task: str) -> Dict:
    """Verify Grok's output with Claude API (REAL VERSION)"""
    
    try:
        # Construct verification prompt
        verification_prompt = f"""You are a verification AI checking another AI's work.

Original Task: {original_task}

AI Output to Verify:
{json.dumps(result, indent=2)}

Your job:
1. Check for logical errors
2. Verify calculations/pricing
3. Detect any hallucinations or false information
4. Ensure the output makes business sense

Return JSON with:
- verified: true/false
- issues: list of any problems found
- confidence: your confidence in the original output (0-1)
- verification_notes: brief summary"""

        # Call Claude API
        message = claude_client.messages.create(
            model="claude-sonnet-4-20250514",  # Latest Claude model
            max_tokens=1000,
            temperature=0,  # Zero temp for strict verification
            messages=[
                {"role": "user", "content": verification_prompt}
            ]
        )
        
        # Parse Claude's verification
        verification_text = message.content[0].text
        
        try:
            verification_data = json.loads(verification_text)
        except:
            # If Claude didn't return JSON, treat as text
            verification_data = {
                "verified": "error" not in verification_text.lower(),
                "issues": [],
                "confidence": 0.7,
                "verification_notes": verification_text[:200]
            }
        
        # Add verification to result
        result['verified'] = verification_data.get('verified', False)
        result['verification_notes'] = verification_data.get('verification_notes', 'Verified by Claude')
        result['verification_confidence'] = verification_data.get('confidence', 0.7)
        result['issues_found'] = verification_data.get('issues', [])
        
        return result
        
    except Exception as e:
        result['verified'] = False
        result['verification_error'] = str(e)
        return result

# ============================================================================
# STEP 4: Email Integration (Real IMAP/SMTP)
# ============================================================================

import imaplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib

async def check_inbox():
    """Check email inbox for new messages (REAL VERSION)"""
    
    # Connect to IMAP
    mail = imaplib.IMAP4_SSL(os.getenv('EMAIL_HOST', 'imap.gmail.com'))
    mail.login(
        os.getenv('EMAIL_USER'),
        os.getenv('EMAIL_PASSWORD')
    )
    
    # Select inbox
    mail.select('inbox')
    
    # Search for unread emails
    _, message_numbers = mail.search(None, 'UNSEEN')
    
    emails = []
    for num in message_numbers[0].split():
        _, msg_data = mail.fetch(num, '(RFC822)')
        email_body = msg_data[0][1]
        email_message = email.message_from_bytes(email_body)
        
        emails.append({
            'from': email_message['from'],
            'subject': email_message['subject'],
            'body': email_message.get_payload(),
            'date': email_message['date']
        })
    
    mail.close()
    mail.logout()
    
    return emails


async def send_email(to: str, subject: str, body: str):
    """Send email via SMTP (REAL VERSION)"""
    
    msg = MIMEMultipart()
    msg['From'] = os.getenv('EMAIL_USER')
    msg['To'] = to
    msg['Subject'] = subject
    
    msg.attach(MIMEText(body, 'plain'))
    
    # Send via SMTP
    server = smtplib.SMTP(
        os.getenv('EMAIL_HOST', 'smtp.gmail.com'),
        int(os.getenv('EMAIL_PORT', 587))
    )
    server.starttls()
    server.login(
        os.getenv('EMAIL_USER'),
        os.getenv('EMAIL_PASSWORD')
    )
    
    server.send_message(msg)
    server.quit()

# ============================================================================
# STEP 5: Update Scheduler to Use Real Email
# ============================================================================

# In AutonomousScheduler class:

async def hourly_tasks(self):
    """Tasks that run every hour (REAL VERSION)"""
    while self.is_running:
        print(f"\n⏰ [{datetime.now().strftime('%H:%M:%S')}] Running HOURLY tasks...")
        
        # Check real emails
        new_emails = await check_inbox()
        
        # Process each email with AI
        sales_agent = self.agents[AgentType.SALES]
        for email_data in new_emails:
            await sales_agent.process_enquiry(email_data)
        
        # Check inventory
        logistics_agent = self.agents[AgentType.LOGISTICS]
        await logistics_agent.check_inventory()
        
        # Monitor systems
        support_agent = self.agents[AgentType.SUPPORT]
        await support_agent.monitor_systems()
        
        await asyncio.sleep(3600)  # Wait 1 hour

# ============================================================================
# STEP 6: Test the Integration
# ============================================================================

async def test_real_integration():
    """Test script to verify real API connections"""
    
    print("Testing real API integrations...")
    
    # Test Grok
    print("\n1. Testing Grok API...")
    try:
        response = grok_client.chat.completions.create(
            model="grok-beta",
            messages=[{"role": "user", "content": "Reply with 'WORKING' if you can see this"}],
            max_tokens=10
        )
        print(f"   ✅ Grok: {response.choices[0].message.content}")
    except Exception as e:
        print(f"   ❌ Grok Error: {e}")
    
    # Test Claude
    print("\n2. Testing Claude API...")
    try:
        message = claude_client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=10,
            messages=[{"role": "user", "content": "Reply with 'WORKING' if you can see this"}]
        )
        print(f"   ✅ Claude: {message.content[0].text}")
    except Exception as e:
        print(f"   ❌ Claude Error: {e}")
    
    # Test Email
    print("\n3. Testing Email Connection...")
    try:
        # Just test connection, don't actually send
        server = smtplib.SMTP(
            os.getenv('EMAIL_HOST', 'smtp.gmail.com'),
            int(os.getenv('EMAIL_PORT', 587))
        )
        server.starttls()
        server.login(
            os.getenv('EMAIL_USER'),
            os.getenv('EMAIL_PASSWORD')
        )
        server.quit()
        print("   ✅ Email: Connected successfully")
    except Exception as e:
        print(f"   ❌ Email Error: {e}")
    
    print("\n✅ Integration test complete!")

if __name__ == "__main__":
    import asyncio
    asyncio.run(test_real_integration())

# ============================================================================
# USAGE
# ============================================================================

# 1. Make sure .env has all your API keys:
#    GROK_API_KEY=xai-...
#    CLAUDE_API_KEY=sk-ant-...
#    EMAIL_USER=your@email.com
#    EMAIL_PASSWORD=your-app-password

# 2. Run test:
#    python real_integration.py

# 3. Once tests pass, the system will use real APIs automatically
