#!/bin/bash

# A&I ARMOUR - Quick Start Script
# One command to get everything running

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║              A&I ARMOUR - QUICK START                     ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "⚙️  Setting up configuration..."
    cp .env.example .env
    echo "✅ Created .env file"
    echo ""
    echo "⚠️  IMPORTANT: Edit .env and add your API keys!"
    echo "   nano .env"
    echo ""
    read -p "Press ENTER after you've added your API keys..."
fi

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    echo "   Install from: https://www.python.org/downloads/"
    exit 1
fi

echo "🔧 Checking Python version..."
python3 --version

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
    echo "✅ Virtual environment created"
fi

# Activate virtual environment
echo "🔌 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📥 Installing dependencies..."
pip install -q -r requirements.txt
echo "✅ Dependencies installed"

# Ask user what they want to do
echo ""
echo "What would you like to do?"
echo ""
echo "1) Run DEMO (see the system in action)"
echo "2) Start API SERVER (run the full dashboard)"
echo "3) Start AUTONOMOUS MODE (24/7 operation)"
echo ""
read -p "Enter your choice (1-3): " choice

case $choice in
    1)
        echo ""
        echo "🎬 Starting demo..."
        python demo.py
        ;;
    2)
        echo ""
        echo "🚀 Starting API server..."
        echo "   Dashboard will be at: http://localhost:8000"
        echo "   API docs at: http://localhost:8000/docs"
        echo ""
        python api_server.py
        ;;
    3)
        echo ""
        echo "🤖 Starting AUTONOMOUS MODE..."
        echo "   System will run 24/7 without supervision"
        echo "   Press Ctrl+C to stop"
        echo ""
        python api_server.py &
        sleep 2
        curl -X POST http://localhost:8000/api/system/start-autonomous
        echo ""
        echo "✅ Autonomous mode activated!"
        echo "   View dashboard: http://localhost:8000"
        wait
        ;;
    *)
        echo "Invalid choice. Exiting."
        exit 1
        ;;
esac
